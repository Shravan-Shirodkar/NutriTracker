import os
import logging
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from werkzeug.middleware.proxy_fix import ProxyFix
from PIL import Image
import uuid
from fatsecret_client import FatSecretClient
from nutrition_calculator import NutritionCalculator

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configuration
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'}

# Initialize FatSecret client
fatsecret_client = FatSecretClient()
nutrition_calculator = NutritionCalculator()

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def init_session():
    """Initialize session data if not exists"""
    if 'user_data' not in session:
        session['user_data'] = {
            'daily_intake': {'calories': 0, 'protein': 0, 'fat': 0, 'carbs': 0},
            'food_entries': [],
            'searched_foods': []
        }

@app.route('/')
def dashboard():
    init_session()
    user_data = session['user_data']
    
    # Calculate daily summary
    daily_summary = {
        'total_calories': user_data['daily_intake']['calories'],
        'total_protein': user_data['daily_intake']['protein'],
        'total_fat': user_data['daily_intake']['fat'],
        'total_carbs': user_data['daily_intake']['carbs'],
        'entries_count': len(user_data['food_entries']),
        'last_entry': user_data['food_entries'][-1] if user_data['food_entries'] else None
    }
    
    return render_template('dashboard.html', summary=daily_summary)

@app.route('/food-recognition', methods=['GET', 'POST'])
def food_recognition():
    init_session()
    
    if request.method == 'POST':
        try:
            # Get food name from form
            food_name = request.form.get('food_name', '').strip()
            
            if not food_name:
                flash('Please enter a food name to search for nutrition information', 'warning')
                return redirect(request.url)
            
            # Search for food using FatSecret API
            try:
                foods = fatsecret_client.search_food(food_name)
                
                if foods:
                    # Get detailed nutrition for first result
                    food_id = foods[0]['food_id']
                    nutrition_data = fatsecret_client.get_food_nutrition(food_id)
                    
                    # Store in session
                    session['user_data']['searched_foods'].append({
                        'id': str(uuid.uuid4()),
                        'name': nutrition_data['food_name'],
                        'nutrition': nutrition_data,
                        'timestamp': datetime.now().isoformat()
                    })
                    session.modified = True
                    
                    return render_template('food_recognition.html', 
                                         nutrition_data=nutrition_data,
                                         searched_name=food_name)
                else:
                    flash(f'No nutrition data found for "{food_name}"', 'warning')
                    return render_template('food_recognition.html', searched_name=food_name)
                    
            except Exception as e:
                logging.error(f"Error fetching nutrition data: {e}")
                flash('Error fetching nutrition data from FatSecret API. Please check your internet connection and try again.', 'error')
                return render_template('food_recognition.html', searched_name=food_name)
                
        except Exception as e:
            logging.error(f"Error in food recognition: {e}")
            flash('An error occurred while processing your request', 'error')
    
    return render_template('food_recognition.html')

@app.route('/diet-recommendations', methods=['GET', 'POST'])
def diet_recommendations():
    init_session()
    
    if request.method == 'POST':
        try:
            # Get user input
            age = int(request.form['age'])
            gender = request.form['gender']
            height = float(request.form['height'])
            weight = float(request.form['weight'])
            goal = request.form['goal']
            activity_level = request.form['activity_level']
            
            # Calculate daily caloric requirement
            calories_needed = nutrition_calculator.calculate_daily_calories(
                age, gender, height, weight, goal, activity_level
            )
            
            # Generate meal plan
            meal_plan = nutrition_calculator.generate_meal_plan(calories_needed)
            
            user_profile = {
                'age': age,
                'gender': gender,
                'height': height,
                'weight': weight,
                'goal': goal,
                'activity_level': activity_level,
                'calories_needed': calories_needed
            }
            
            return render_template('diet_recommendations.html', 
                                 user_profile=user_profile, 
                                 meal_plan=meal_plan)
            
        except ValueError as e:
            flash('Please enter valid numeric values', 'error')
        except Exception as e:
            logging.error(f"Error calculating diet recommendations: {e}")
            flash('Error calculating recommendations', 'error')
    
    return render_template('diet_recommendations.html')

@app.route('/analysis', methods=['GET', 'POST'])
def analysis():
    init_session()
    
    if request.method == 'POST':
        try:
            food_name = request.form['food_name'].strip()
            quantity = float(request.form['quantity'])
            
            if not food_name:
                flash('Please enter a food name', 'error')
                return redirect(request.url)
            
            # Search for food
            foods = fatsecret_client.search_food(food_name)
            
            if foods:
                food_id = foods[0]['food_id']
                nutrition_data = fatsecret_client.get_food_nutrition(food_id)
                
                # Calculate nutrition based on quantity
                adjusted_nutrition = nutrition_calculator.calculate_portion_nutrition(
                    nutrition_data, quantity
                )
                
                # Add to daily intake
                user_data = session['user_data']
                user_data['daily_intake']['calories'] += adjusted_nutrition['calories']
                user_data['daily_intake']['protein'] += adjusted_nutrition['protein']
                user_data['daily_intake']['fat'] += adjusted_nutrition['fat']
                user_data['daily_intake']['carbs'] += adjusted_nutrition['carbs']
                
                # Add to food entries
                user_data['food_entries'].append({
                    'id': str(uuid.uuid4()),
                    'name': nutrition_data['food_name'],
                    'quantity': quantity,
                    'nutrition': adjusted_nutrition,
                    'timestamp': datetime.now().isoformat()
                })
                
                session.modified = True
                flash(f'Added {food_name} to your daily intake', 'success')
            else:
                flash(f'No nutrition data found for "{food_name}"', 'warning')
                
        except ValueError:
            flash('Please enter a valid quantity', 'error')
        except Exception as e:
            logging.error(f"Error in analysis: {e}")
            flash('Error adding food entry', 'error')
    
    user_data = session['user_data']
    return render_template('analysis.html', 
                         daily_intake=user_data['daily_intake'],
                         food_entries=user_data['food_entries'])

@app.route('/data-viewer')
def data_viewer():
    init_session()
    user_data = session['user_data']
    
    # Combine searched foods and food entries
    all_foods = []
    
    # Add searched foods
    for food in user_data['searched_foods']:
        all_foods.append({
            'id': food['id'],
            'name': food['name'],
            'type': 'Searched',
            'nutrition': food['nutrition'],
            'timestamp': food['timestamp'],
            'quantity': 'N/A'
        })
    
    # Add food entries
    for entry in user_data['food_entries']:
        all_foods.append({
            'id': entry['id'],
            'name': entry['name'],
            'type': 'Daily Entry',
            'nutrition': entry['nutrition'],
            'timestamp': entry['timestamp'],
            'quantity': entry['quantity']
        })
    
    # Sort by timestamp (most recent first)
    all_foods.sort(key=lambda x: x['timestamp'], reverse=True)
    
    return render_template('data_viewer.html', foods=all_foods)

@app.route('/delete-entry/<entry_id>')
def delete_entry(entry_id):
    init_session()
    user_data = session['user_data']
    
    # Remove from searched foods
    user_data['searched_foods'] = [
        food for food in user_data['searched_foods'] 
        if food['id'] != entry_id
    ]
    
    # Remove from food entries and update daily intake
    for entry in user_data['food_entries']:
        if entry['id'] == entry_id:
            # Subtract from daily intake
            user_data['daily_intake']['calories'] -= entry['nutrition']['calories']
            user_data['daily_intake']['protein'] -= entry['nutrition']['protein']
            user_data['daily_intake']['fat'] -= entry['nutrition']['fat']
            user_data['daily_intake']['carbs'] -= entry['nutrition']['carbs']
            break
    
    user_data['food_entries'] = [
        entry for entry in user_data['food_entries'] 
        if entry['id'] != entry_id
    ]
    
    session.modified = True
    flash('Entry deleted successfully', 'success')
    
    return redirect(url_for('data_viewer'))

@app.route('/clear-all-data')
def clear_all_data():
    session['user_data'] = {
        'daily_intake': {'calories': 0, 'protein': 0, 'fat': 0, 'carbs': 0},
        'food_entries': [],
        'searched_foods': []
    }
    session.modified = True
    flash('All data cleared successfully', 'success')
    
    return redirect(url_for('data_viewer'))

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
