import os
import logging
import requests
import json
import hmac
import hashlib
import base64
import time
import random
from urllib.parse import urlencode, quote

class FatSecretClient:
    def __init__(self):
        self.consumer_key = os.environ.get('FATSECRET_CONSUMER_KEY', '4d62e25e478d42bb9a648ed51e0721d7')
        self.consumer_secret = os.environ.get('FATSECRET_CONSUMER_SECRET', '0599cb06cbb84fc9a3c80d93d7a9412d')
        self.base_url = 'https://platform.fatsecret.com/rest/server.api'
    
    def _generate_oauth_signature(self, method, url, params):
        """Generate OAuth 1.0 signature for FatSecret API"""
        # OAuth parameters
        oauth_params = {
            'oauth_consumer_key': self.consumer_key,
            'oauth_nonce': str(random.randint(100000000000000000, 999999999999999999)),
            'oauth_signature_method': 'HMAC-SHA1',
            'oauth_timestamp': str(int(time.time())),
            'oauth_version': '1.0'
        }
        
        # Combine OAuth params with request params
        all_params = {**params, **oauth_params}
        
        # Sort parameters
        sorted_params = sorted(all_params.items())
        
        # Create parameter string
        param_string = '&'.join([f"{quote(str(k), safe='')}={quote(str(v), safe='')}" for k, v in sorted_params])
        
        # Create signature base string
        signature_base = f"{method.upper()}&{quote(url, safe='')}&{quote(param_string, safe='')}"
        
        # Create signing key
        signing_key = f"{quote(self.consumer_secret, safe='')}&"
        
        # Generate signature
        signature = base64.b64encode(
            hmac.new(signing_key.encode(), signature_base.encode(), hashlib.sha1).digest()
        ).decode()
        
        # Add signature to OAuth params
        oauth_params['oauth_signature'] = signature
        
        return oauth_params
    
    def _make_request(self, method, **params):
        """Make a request to FatSecret API"""
        try:
            # Prepare parameters
            params['method'] = method
            params['format'] = 'json'
            
            # Generate OAuth signature
            oauth_params = self._generate_oauth_signature('POST', self.base_url, params)
            
            # Add OAuth parameters to request data
            all_params = {**params, **oauth_params}
            
            logging.debug(f"OAuth params: {oauth_params}")
            logging.debug(f"All params: {all_params}")
            
            # Make request
            response = requests.post(
                self.base_url,
                data=all_params,
                timeout=30
            )
            
            if response.status_code == 200:
                json_response = response.json()
                logging.debug(f"FatSecret API response: {json_response}")
                
                # Check if the response contains an error
                if 'error' in json_response:
                    logging.error(f"FatSecret API error in response: {json_response['error']}")
                    return None
                    
                return json_response
            else:
                logging.error(f"FatSecret API error: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            logging.error(f"Error making FatSecret API request: {e}")
            return None
    
    def search_food(self, query, max_results=10):
        """Search for foods by name"""
        try:
            response = self._make_request(
                'foods.search',
                search_expression=query,
                max_results=max_results
            )
            
            if response and 'foods' in response:
                foods = response['foods']
                if 'food' in foods:
                    food_list = foods['food']
                    # Handle both single food and list of foods
                    if isinstance(food_list, dict):
                        return [food_list]
                    return food_list
            
            return []
            
        except Exception as e:
            logging.error(f"Error searching for food: {e}")
            return []
    
    def get_food_nutrition(self, food_id):
        """Get detailed nutrition information for a specific food"""
        try:
            response = self._make_request('food.get', food_id=food_id)
            
            if response and 'food' in response:
                food_data = response['food']
                
                # Parse nutrition data
                nutrition_info = {
                    'food_id': food_data.get('food_id'),
                    'food_name': food_data.get('food_name'),
                    'food_type': food_data.get('food_type'),
                    'brand_name': food_data.get('brand_name', ''),
                    'food_url': food_data.get('food_url', ''),
                    'calories': 0,
                    'protein': 0,
                    'fat': 0,
                    'carbs': 0,
                    'fiber': 0,
                    'sugar': 0,
                    'sodium': 0,
                    'cholesterol': 0,
                    'saturated_fat': 0,
                    'serving_description': '',
                    'serving_size': 1
                }
                
                # Extract serving information
                if 'servings' in food_data:
                    servings = food_data['servings']
                    if 'serving' in servings:
                        serving_data = servings['serving']
                        
                        # Handle both single serving and list of servings
                        if isinstance(serving_data, list):
                            serving_data = serving_data[0]  # Use first serving
                        
                        # Extract nutrition values
                        nutrition_info.update({
                            'calories': float(serving_data.get('calories', 0)),
                            'protein': float(serving_data.get('protein', 0)),
                            'fat': float(serving_data.get('fat', 0)),
                            'carbs': float(serving_data.get('carbohydrate', 0)),
                            'fiber': float(serving_data.get('fiber', 0)),
                            'sugar': float(serving_data.get('sugar', 0)),
                            'sodium': float(serving_data.get('sodium', 0)),
                            'cholesterol': float(serving_data.get('cholesterol', 0)),
                            'saturated_fat': float(serving_data.get('saturated_fat', 0)),
                            'serving_description': serving_data.get('serving_description', ''),
                            'serving_size': float(serving_data.get('number_of_units', 1))
                        })
                
                return nutrition_info
            
            return None
            
        except Exception as e:
            logging.error(f"Error getting food nutrition: {e}")
            return None
    
    def get_food_autocomplete(self, query):
        """Get autocomplete suggestions for food names"""
        try:
            response = self._make_request(
                'foods.autocomplete',
                expression=query
            )
            
            if response and 'suggestions' in response:
                suggestions = response['suggestions']
                if 'suggestion' in suggestions:
                    return suggestions['suggestion']
            
            return []
            
        except Exception as e:
            logging.error(f"Error getting food autocomplete: {e}")
            return []
