import logging
from typing import Dict, List, Any

class NutritionCalculator:
    def __init__(self):
        # Activity level multipliers
        self.activity_multipliers = {
            'sedentary': 1.2,
            'lightly_active': 1.375,
            'moderately_active': 1.55,
            'very_active': 1.725,
            'extremely_active': 1.9
        }
        
        # Sample meal plan database (in a real app, this would be more comprehensive)
        self.meal_plans = {
            'breakfast': [
                {'name': 'Oatmeal with berries', 'calories': 300, 'protein': 10, 'fat': 6, 'carbs': 54},
                {'name': 'Greek yogurt with granola', 'calories': 250, 'protein': 15, 'fat': 8, 'carbs': 30},
                {'name': 'Scrambled eggs with toast', 'calories': 350, 'protein': 18, 'fat': 20, 'carbs': 25},
                {'name': 'Smoothie bowl', 'calories': 280, 'protein': 12, 'fat': 8, 'carbs': 42}
            ],
            'lunch': [
                {'name': 'Grilled chicken salad', 'calories': 400, 'protein': 35, 'fat': 18, 'carbs': 25},
                {'name': 'Quinoa bowl with vegetables', 'calories': 450, 'protein': 15, 'fat': 16, 'carbs': 65},
                {'name': 'Turkey sandwich', 'calories': 380, 'protein': 25, 'fat': 12, 'carbs': 45},
                {'name': 'Vegetable stir-fry with rice', 'calories': 420, 'protein': 12, 'fat': 14, 'carbs': 68}
            ],
            'dinner': [
                {'name': 'Baked salmon with sweet potato', 'calories': 500, 'protein': 40, 'fat': 22, 'carbs': 35},
                {'name': 'Lean beef with broccoli', 'calories': 480, 'protein': 42, 'fat': 20, 'carbs': 28},
                {'name': 'Chicken breast with quinoa', 'calories': 450, 'protein': 38, 'fat': 15, 'carbs': 40},
                {'name': 'Vegetarian pasta', 'calories': 420, 'protein': 18, 'fat': 12, 'carbs': 65}
            ],
            'snacks': [
                {'name': 'Apple with almond butter', 'calories': 190, 'protein': 6, 'fat': 11, 'carbs': 22},
                {'name': 'Greek yogurt', 'calories': 120, 'protein': 15, 'fat': 2, 'carbs': 12},
                {'name': 'Mixed nuts', 'calories': 160, 'protein': 6, 'fat': 14, 'carbs': 6},
                {'name': 'Protein bar', 'calories': 200, 'protein': 15, 'fat': 8, 'carbs': 20}
            ]
        }
    
    def calculate_bmr(self, age: int, gender: str, height: float, weight: float) -> float:
        """Calculate Basal Metabolic Rate using Mifflin-St Jeor equation"""
        try:
            if gender.lower() == 'male':
                bmr = 10 * weight + 6.25 * height - 5 * age + 5
            else:  # female
                bmr = 10 * weight + 6.25 * height - 5 * age - 161
            
            return bmr
            
        except Exception as e:
            logging.error(f"Error calculating BMR: {e}")
            return 0
    
    def calculate_daily_calories(self, age: int, gender: str, height: float, weight: float, 
                               goal: str, activity_level: str) -> int:
        """Calculate daily caloric needs based on user profile and goals"""
        try:
            # Calculate BMR
            bmr = self.calculate_bmr(age, gender, height, weight)
            
            # Apply activity multiplier
            activity_multiplier = self.activity_multipliers.get(activity_level, 1.2)
            tdee = bmr * activity_multiplier
            
            # Adjust for goal
            if goal == 'weight_loss':
                # Create 500 calorie deficit for 1 lb/week loss
                daily_calories = tdee - 500
                # Don't go below 1200 calories for women or 1500 for men
                min_calories = 1200 if gender.lower() == 'female' else 1500
                daily_calories = max(daily_calories, min_calories)
            elif goal == 'weight_gain':
                # Create 500 calorie surplus for 1 lb/week gain
                daily_calories = tdee + 500
            else:  # maintenance
                daily_calories = tdee
            
            return int(daily_calories)
            
        except Exception as e:
            logging.error(f"Error calculating daily calories: {e}")
            return 2000  # Default fallback
    
    def generate_meal_plan(self, target_calories: int) -> Dict[str, Any]:
        """Generate a meal plan based on target calories"""
        try:
            # Calculate calorie distribution
            breakfast_calories = int(target_calories * 0.25)  # 25%
            lunch_calories = int(target_calories * 0.35)      # 35%
            dinner_calories = int(target_calories * 0.30)     # 30%
            snack_calories = int(target_calories * 0.10)      # 10%
            
            meal_plan = {
                'target_calories': target_calories,
                'breakfast': self._select_meal('breakfast', breakfast_calories),
                'lunch': self._select_meal('lunch', lunch_calories),
                'dinner': self._select_meal('dinner', dinner_calories),
                'snacks': self._select_meal('snacks', snack_calories)
            }
            
            # Calculate totals
            total_calories = (meal_plan['breakfast']['calories'] + 
                            meal_plan['lunch']['calories'] + 
                            meal_plan['dinner']['calories'] + 
                            meal_plan['snacks']['calories'])
            
            total_protein = (meal_plan['breakfast']['protein'] + 
                           meal_plan['lunch']['protein'] + 
                           meal_plan['dinner']['protein'] + 
                           meal_plan['snacks']['protein'])
            
            total_fat = (meal_plan['breakfast']['fat'] + 
                        meal_plan['lunch']['fat'] + 
                        meal_plan['dinner']['fat'] + 
                        meal_plan['snacks']['fat'])
            
            total_carbs = (meal_plan['breakfast']['carbs'] + 
                          meal_plan['lunch']['carbs'] + 
                          meal_plan['dinner']['carbs'] + 
                          meal_plan['snacks']['carbs'])
            
            meal_plan['totals'] = {
                'calories': total_calories,
                'protein': total_protein,
                'fat': total_fat,
                'carbs': total_carbs
            }
            
            return meal_plan
            
        except Exception as e:
            logging.error(f"Error generating meal plan: {e}")
            return {}
    
    def _select_meal(self, meal_type: str, target_calories: int) -> Dict[str, Any]:
        """Select the best meal option for the target calories"""
        try:
            meals = self.meal_plans.get(meal_type, [])
            
            if not meals:
                return {'name': 'No options available', 'calories': 0, 'protein': 0, 'fat': 0, 'carbs': 0}
            
            # Find the meal closest to target calories
            best_meal = min(meals, key=lambda x: abs(x['calories'] - target_calories))
            
            return best_meal.copy()
            
        except Exception as e:
            logging.error(f"Error selecting meal: {e}")
            return {'name': 'Error', 'calories': 0, 'protein': 0, 'fat': 0, 'carbs': 0}
    
    def calculate_portion_nutrition(self, base_nutrition: Dict[str, Any], quantity: float) -> Dict[str, Any]:
        """Calculate nutrition values for a specific portion size"""
        try:
            portion_nutrition = {
                'calories': round(base_nutrition.get('calories', 0) * quantity, 1),
                'protein': round(base_nutrition.get('protein', 0) * quantity, 1),
                'fat': round(base_nutrition.get('fat', 0) * quantity, 1),
                'carbs': round(base_nutrition.get('carbs', 0) * quantity, 1),
                'fiber': round(base_nutrition.get('fiber', 0) * quantity, 1),
                'sugar': round(base_nutrition.get('sugar', 0) * quantity, 1),
                'sodium': round(base_nutrition.get('sodium', 0) * quantity, 1),
                'cholesterol': round(base_nutrition.get('cholesterol', 0) * quantity, 1),
                'saturated_fat': round(base_nutrition.get('saturated_fat', 0) * quantity, 1)
            }
            
            return portion_nutrition
            
        except Exception as e:
            logging.error(f"Error calculating portion nutrition: {e}")
            return {'calories': 0, 'protein': 0, 'fat': 0, 'carbs': 0, 'fiber': 0, 'sugar': 0, 'sodium': 0, 'cholesterol': 0, 'saturated_fat': 0}
    
    def calculate_bmi(self, height: float, weight: float) -> Dict[str, Any]:
        """Calculate BMI and category"""
        try:
            # Convert height from cm to m
            height_m = height / 100
            bmi = weight / (height_m ** 2)
            
            # Determine category
            if bmi < 18.5:
                category = 'Underweight'
            elif bmi < 25:
                category = 'Normal weight'
            elif bmi < 30:
                category = 'Overweight'
            else:
                category = 'Obese'
            
            return {
                'bmi': round(bmi, 1),
                'category': category
            }
            
        except Exception as e:
            logging.error(f"Error calculating BMI: {e}")
            return {'bmi': 0, 'category': 'Unknown'}
